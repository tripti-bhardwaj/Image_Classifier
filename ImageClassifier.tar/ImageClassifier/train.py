import argparse
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from collections import OrderedDict
from utils_train import load_data, build_dl_model

def arg_parser():
    parser = argparse.ArgumentParser(description="Train.py")
    parser.add_argument('data_directory', action="store")
    parser.add_argument('--save_dir', action="store", dest="save_dir", default=".")
    parser.add_argument('--arch', action="store", dest="arch", default="vgg16")
    parser.add_argument('--learning_rate', action="store", dest="learning_rate", default=0.001)
    parser.add_argument('--hidden_units', action="store", dest="hidden_units", default=120)
    parser.add_argument('--epochs', action="store", dest="epochs", default=12)
    parser.add_argument('--gpu', action="store_true", dest="gpu", default=False)
    args = parser.parse_args()
    return args

def main():
    args = arg_parser()

    if args.gpu and not torch.cuda.is_available():
        print("There is no GPU device available.")
        return

    trainloader, validloader, testloader, class_to_idx = load_data(args.data_directory)

    model = build_dl_model(args.arch, int(args.hidden_units))
    message_cuda = "CUDA is available" if torch.cuda.is_available() else "CUDA is not available"
    print(message_cuda)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.classifier.parameters(), lr=float(args.learning_rate))

    steps = 0
    running_loss = 0
    print_every = 30

    for epoch in range(int(args.epochs)):
        for inputs, labels in trainloader:
            steps += 1
            inputs, labels = inputs.to(device), labels.to(device)

            optimizer.zero_grad()
            logps = model.forward(inputs)
            loss = criterion(logps, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

            if steps % print_every == 0:
                valid_loss = 0
                accuracy = 0
                model.eval()

                with torch.no_grad():
                    for inputs, labels in validloader:
                        inputs, labels = inputs.to(device), labels.to(device)
                        logps = model.forward(inputs)
                        batch_loss = criterion(logps, labels)
                        valid_loss += batch_loss.item()

                        ps = torch.exp(logps)
                        top_p, top_class = ps.topk(1, dim=1)
                        equals = top_class == labels.view(*top_class.shape)
                        accuracy += torch.mean(equals.type(torch.FloatTensor)).item()

                print(f"Epoch {epoch+1}/{args.epochs}.. "
                      f"Train loss: {running_loss/print_every:.3f}.. "
                      f"Valid loss: {valid_loss/len(validloader):.3f}.. "
                      f"Valid accuracy: {accuracy/len(validloader):.3f}")
                running_loss = 0
                model.train()

    # Validate the model on test data
    test_loss = 0
    accuracy = 0

    with torch.no_grad():
        for inputs, labels in testloader:
            inputs, labels = inputs.to(device), labels.to(device)
            logps = model.forward(inputs)
            batch_loss = criterion(logps, labels)
            test_loss += batch_loss.item()

            ps = torch.exp(logps)
            top_p, top_class = ps.topk(1, dim=1)
            equals = top_class == labels.view(*top_class.shape)
            accuracy += torch.mean(equals.type(torch.FloatTensor)).item()

    print(f"Test loss: {test_loss/len(testloader):.3f}.. "
          f"Test accuracy: {accuracy/len(testloader):.3f}")

    # Save the checkpoint
    checkpoint = {
        'arch': args.arch,
        'state_dict': model.state_dict(),
        'class_to_idx': class_to_idx,
        'hidden_units': int(args.hidden_units)
    }

    save_path = os.path.join(args.save_dir, 'checkpoint.pth')
    torch.save(checkpoint, save_path)
    print(f"Checkpoint saved at {save_path}")

if __name__ == '__main__':
    main()
